package com.example.datingapp.auth

data class UserDataModel(

    val uid : String? = null,
    val nickname : String? = null,
    val sex : String? = null,
    val location : String? = null,
    val age : String? = null

)
